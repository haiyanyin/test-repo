from distutils.core import setup
from setuptools import find_packages

setup(
    name="achievement_distillation",
    version="0.0.1",
    packages=find_packages(),
    license="MIT License",
)
