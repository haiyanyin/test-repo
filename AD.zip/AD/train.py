import argparse
import datetime
from functools import partial
import json
import os
import random
import sys
import yaml

import numpy as np
import torch as th

from crafter.env import Env
from stable_baselines3.common.vec_env.subproc_vec_env import SubprocVecEnv
from stable_baselines3.common.vec_env.vec_monitor import VecMonitor

from achievement_distillation.algorithm import *
from achievement_distillation.constant import TASKS
from achievement_distillation.logger import Logger
from achievement_distillation.model import *
from achievement_distillation.sample import sample_rollouts
from achievement_distillation.storage import RolloutStorage
from achievement_distillation.wrapper import VecPyTorch

import torch.nn.functional as F
import torch.nn as nn
import math
import torch.optim as optim
from achievement_distillation.torch_util import FanInInitReLULayer
from typing import List


@th.no_grad()
def _kaiming_uniform_reinit(layer: nn.Linear | nn.Conv2d, mask: th.Tensor) -> None:
    """Partially re-initializes the bias of a layer according to the Kaiming uniform scheme."""

    # This is adapted from https://pytorch.org/docs/stable/_modules/torch/nn/init.html#kaiming_uniform_
    fan_in = nn.init._calculate_correct_fan(tensor=layer.weight, mode="fan_in")
    gain = nn.init.calculate_gain(nonlinearity="relu", param=math.sqrt(5))
    std = gain / math.sqrt(fan_in)
    # Calculate uniform bounds from standard deviation
    bound = math.sqrt(3.0) * std
    layer.weight.data[mask, ...] = th.empty_like(layer.weight.data[mask, ...]).uniform_(-bound, bound)

    if layer.bias is not None:
        # The original code resets the bias to 0.0 because it uses a different initialization scheme
        # layer.bias.data[mask] = 0.0
        if isinstance(layer, nn.Conv2d):
            if fan_in != 0:
                bound = 1 / math.sqrt(fan_in)
                layer.bias.data[mask, ...] = th.empty_like(layer.bias.data[mask, ...]).uniform_(-bound, bound)
        else:
            bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
            layer.bias.data[mask, ...] = th.empty_like(layer.bias.data[mask, ...]).uniform_(-bound, bound)


@th.inference_mode()
def _get_activation(name: str, activations: dict[str, th.Tensor]):
    """Fetches and stores the activations of a network layer."""

    def hook(layer: nn.Linear | nn.Conv2d, input: tuple[th.Tensor], output: th.Tensor) -> None:
        """
        Get the activations of a layer with relu nonlinearity.
        ReLU has to be called explicitly here because the hook is attached to the conv/linear layer.
        """
        if isinstance(layer, nn.Linear) or isinstance(layer, nn.Conv2d):
            activations[name] = F.relu(output)

    return hook


@th.inference_mode()
def _get_redo_masks(activations: dict[str, th.Tensor], tau: float) -> th.Tensor:
    """
    Computes the ReDo mask for a given set of activations.
    The returned mask has True where neurons are dormant and False where they are active.
    """
    masks = []

    # Last activation are the q-values, which are never reset
    for name, activation in list(activations.items())[:-1]:
        # Taking the mean here conforms to the expectation under D in the main paper's formula
        if activation.ndim == 4:
            # Conv layer
            score = activation.abs().mean(dim=(0, 2, 3))
        else:
            # Linear layer
            score = activation.abs().mean(dim=0)

        # Divide by activation mean to make the threshold independent of the layer size
        # see https://github.com/google/dopamine/blob/ce36aab6528b26a699f5f1cefd330fdaf23a5d72/dopamine/labs/redo/weight_recyclers.py#L314
        # https://github.com/google/dopamine/issues/209
        normalized_score = score / (score.mean() + 1e-9)

        layer_mask = th.zeros_like(normalized_score, dtype=th.bool)
        if tau > 0.0:
            layer_mask[normalized_score <= tau] = 1
        else:
            layer_mask[th.isclose(normalized_score, th.zeros_like(normalized_score))] = 1
        masks.append(layer_mask)
    return masks



@th.no_grad()
def _reset_dormant_neurons(model: PPOADModel, redo_masks: th.Tensor, mask_names: List, use_lecun_init: bool = False): # -> QNetwork
    """Re-initializes the dormant neurons of a model."""

    # layers = [(name, layer) for name, layer in list(model.named_modules())[1:]]

    layers = []

    for name, layer in list(model.named_modules())[1:]:
        if isinstance(layer, th.nn.Conv2d) or isinstance(layer, th.nn.Linear): #or isinstance(layer, FanInInitReLULayer):
            if not 'next_goal_pred' in name and not 'action_mlp' in name:
                layers += [(name, layer)]

    # print(len(redo_masks), len(layers), len(mask_names))
    # for mask_name in mask_names:
    #     print(mask_name)
    
    assert len(redo_masks) == len(layers) - 1, "Number of masks must match the number of layers"

    # Reset the ingoing weights
    # Here the mask size always matches the layer weight size
    for i in range(len(layers[:-1])):
        mask = redo_masks[i]
        layer = layers[i][1]
        next_layer = layers[i + 1][1]
        # Can be used to not reset outgoing weights in the Q-function
        next_layer_name = layers[i + 1][0]

        # Skip if there are no dead neurons
        if th.all(~mask):
            # No dormant neurons in this layer
            continue

        # The initialization scheme is the same for conv2d and linear
        # 1. Reset the ingoing weights using the initialization distribution
        if use_lecun_init:
            # _lecun_normal_reinit(layer, mask)
            raise NotImplementedError
        else:
            _kaiming_uniform_reinit(layer, mask)

        # 2. Reset the outgoing weights to 0
        # NOTE: Don't reset the bias for the following layer or else you will create new dormant neurons
        # To not reset in the last layer: and not next_layer_name == 'q'

        # print('mask i', i, mask.shape, type(layer), type(next_layer), layer.weight.shape, next_layer.weight.shape)
        if isinstance(layer, nn.Conv2d) and isinstance(next_layer, nn.Linear):
            # Special case: Transition from conv to linear layer
            # Reset the outgoing weights to 0 with a mask created from the conv filters
            num_repeatition = next_layer.weight.data.shape[1] // mask.shape[0]
            linear_mask = th.repeat_interleave(mask, num_repeatition)
            next_layer.weight.data[:, linear_mask] = 0.0
        elif mask.shape[0] == next_layer.weight.data.shape[1]:
            # Standard case: layer and next_layer are both conv or both linear
            # Reset the outgoing weights to 0
            next_layer.weight.data[:, mask, ...] = 0.0
        else:
            pass 
            #TODO: verify last two layers [pi_head, vi_head...]
            # print("shape not aligned", i)
    return model


@th.no_grad()
def _reset_adam_moments(optimizer: optim.Adam, reset_masks: dict[str, th.Tensor]) -> optim.Adam:
    """Resets the moments of the Adam optimizer for the dormant neurons."""
    # print("optimizer:", len(optimizer.state_dict()["state"]))
    assert isinstance(optimizer, optim.Adam), "Moment resetting currently only supported for Adam optimizer"
    for i, mask in enumerate(reset_masks):
        # Reset the moments for the weights
        optimizer.state_dict()["state"][i * 2]["exp_avg"][mask, ...] = 0.0
        optimizer.state_dict()["state"][i * 2]["exp_avg_sq"][mask, ...] = 0.0
        # NOTE: Step count resets are key to the algorithm's performance
        # It's possible to just reset the step for moment that's being reset
        optimizer.state_dict()["state"][i * 2]["step"].zero_()

        # Reset the moments for the bias
        optimizer.state_dict()["state"][i * 2 + 1]["exp_avg"][mask] = 0.0
        optimizer.state_dict()["state"][i * 2 + 1]["exp_avg_sq"][mask] = 0.0
        optimizer.state_dict()["state"][i * 2 + 1]["step"].zero_()

        # Reset the moments for the output weights
        if (
            len(optimizer.state_dict()["state"][i * 2]["exp_avg"].shape) == 4
            and len(optimizer.state_dict()["state"][i * 2 + 2]["exp_avg"].shape) == 2
        ):
            # Catch transition from conv to linear layer through moment shapes
            num_repeatition = optimizer.state_dict()["state"][i * 2 + 2]["exp_avg"].shape[1] // mask.shape[0]
            linear_mask = th.repeat_interleave(mask, num_repeatition)
            optimizer.state_dict()["state"][i * 2 + 2]["exp_avg"][:, linear_mask] = 0.0
            optimizer.state_dict()["state"][i * 2 + 2]["exp_avg_sq"][:, linear_mask] = 0.0
            optimizer.state_dict()["state"][i * 2 + 2]["step"].zero_()
        else:
            # Standard case: layer and next_layer are both conv or both linear
            # Reset the outgoing weights to 0
            optimizer.state_dict()["state"][i * 2 + 2]["exp_avg"][:, mask, ...] = 0.0
            optimizer.state_dict()["state"][i * 2 + 2]["exp_avg_sq"][:, mask, ...] = 0.0
            optimizer.state_dict()["state"][i * 2 + 2]["step"].zero_()

    return optimizer


@th.inference_mode()
def run_redo(
    obs: th.Tensor,
    states: th.Tensor,
    algorithm: PPOADAlgorithm,
    # model: PPOADModel,
    # optimizer: optim.Adam,
    tau: float,
    re_initialize: bool,
    use_lecun_init: bool,
):
    """
    Checks the number of dormant neurons for a given model.
    If re_initialize is True, then the dormant neurons are re-initialized according to the scheme in
    https://arxiv.org/abs/2302.12902

    Returns the number of dormant neurons.
    """

    assert not use_lecun_init
    model = algorithm.model
    activations = {}
    activation_getter = partial(_get_activation, activations=activations)

    # Register hooks for all Conv2d and Linear layers to calculate activations
    handles = []
    count = 0

    # for name, module in model.named_modules():
    #     print('named modules', name, count)
    #     count += 1
    mask_names = []
    for name, module in model.named_modules():
        if isinstance(module, th.nn.Conv2d) or isinstance(module, th.nn.Linear): #or isinstance(module, FanInInitReLULayer)
            if not 'next_goal_pred' in name and not 'action_mlp' in name:
                handles.append(module.register_forward_hook(activation_getter(name)))
                mask_names.append(name)
            # print('named modules', module)
        else:
            pass
            # print("not Cov2d or Linear", module)
    # Calculate activations
    _ = model(obs, states)

    # Masks for tau=0 logging
    zero_masks = _get_redo_masks(activations, 0.0)
    total_neurons = sum([th.numel(mask) for mask in zero_masks])
    zero_count = sum([th.sum(mask) for mask in zero_masks])
    zero_fraction = (zero_count / total_neurons) * 100

    # Calculate the masks actually used for resetting
    masks = _get_redo_masks(activations, tau)


    #     if mask_n not in activations.keys():
    #         print("not found", mask_n)
    
    dormant_count = sum([th.sum(mask) for mask in masks])
    dormant_fraction = (dormant_count / sum([th.numel(mask) for mask in masks])) * 100

    # Re-initialize the dormant neurons and reset the Adam moments
    if re_initialize:
        print("Re-initializing dormant neurons")
        print(f"Total neurons: {total_neurons} | Dormant neurons: {dormant_count} | Dormant fraction: {dormant_fraction:.2f}%")
        algorithm.model = _reset_dormant_neurons(model, masks, activations.keys(), use_lecun_init)
        #TODO: reset optimizer on masks
        # algorithm.optimizer = _reset_adam_moments(algorithm.optimizer, masks)
        # algorithm.match_optimizer = _reset_adam_moments(algorithm.match_optimizer, masks)
        # algorithm.pred_optimizer = _reset_adam_moments(algorithm.pred_optimizer, masks)

    # Remove the hooks again
    for handle in handles:
        handle.remove()
    
    info = {
            "dormant/zero_fraction": zero_fraction,
            "dormant/zero_count": zero_count,
            "dormant/dormant_fraction": dormant_fraction,
            "dormant/dormant_count": dormant_count,
        }
    return algorithm, info


def main(args):
    # Load config file
    config_file = open(f"configs/{args.exp_name}.yaml", "r")
    config = yaml.load(config_file, Loader=yaml.FullLoader)

    # Fix random seed
    random.seed(args.seed)
    np.random.seed(args.seed)
    th.manual_seed(args.seed)
    th.cuda.manual_seed_all(args.seed)
    th.backends.cudnn.benchmark = False

    # CUDA setting
    th.set_num_threads(1)
    cuda = th.cuda.is_available()
    device = th.device("cuda:0" if cuda else "cpu")

    # Create logger
    group_name = f"{args.exp_name}-{args.timestamp}"
    run_name = f"{group_name}-{'Dormant-' if args.use_dormant else ''}s{args.seed:02}"

    if args.log_stats:
        # JSON
        log_dir = os.path.join("./logs", run_name)
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(log_dir, "stats.jsonl")
        log_file = open(log_path, "w")

        # W&B
        logger = Logger(config=config, group=group_name, name=run_name)

    # Create checkpoint directory
    if args.save_ckpt:
        ckpt_dir = os.path.join("./models", run_name)
        os.makedirs(ckpt_dir, exist_ok=True)

    # Create environment
    seeds = np.random.randint(0, 2**31 - 1, size=config["nproc"])
    env_fns = [partial(Env, seed=seed) for seed in seeds]
    venv = SubprocVecEnv(env_fns)
    venv = VecMonitor(venv)
    venv = VecPyTorch(venv, device=device)
    obs = venv.reset()

    # Create storage
    storage = RolloutStorage(
        nstep=config["nstep"],
        nproc=config["nproc"],
        observation_space=venv.observation_space,
        action_space=venv.action_space,
        hidsize=config["model_kwargs"]["hidsize"],
        device=device,
        priority_replay=args.priority_replay,
    )
    storage.obs[0].copy_(obs)

    # Create model
    model_cls = getattr(sys.modules[__name__], config["model_cls"])
    model: BaseModel = model_cls(
        observation_space=venv.observation_space,
        action_space=venv.action_space,
        **config["model_kwargs"],
    )
    model = model.to(device)
    print(model)

    # Create algorithm
    algorithm_cls = getattr(sys.modules[__name__], config["algorithm_cls"])
    algorithm: BaseAlgorithm = algorithm_cls(
        model=model,
        **config["algorithm_kwargs"],
    )

    # Run algorithm
    total_successes = np.zeros((0, len(TASKS)), dtype=np.int32)
    dormant_tau = args.dormant_tau
    for epoch in range(1, config["nepoch"] + 1):
        # Sample episodes
        rollout_stats = sample_rollouts(venv, model, storage)

        # Compute returns
        storage.compute_returns(config["gamma"], config["gae_lambda"])

        # Update models
        train_stats = algorithm.update(storage)

        if args.priority_replay and args.log_stats:
            priority_logs = {}

            phase_idx = int(storage.global_steps // storage.switch_priority_achivement_steps)
            priority_achievements = storage.priority_achivements[phase_idx]

            for idx in priority_achievements:
                task_name = f'priority/success-{idx}-{TASKS[idx]}'
                priority_logs.update({task_name: storage.achie_successes_count[idx]})
            logger.log(priority_logs, epoch)

        # Reset storage
        storage.reset()

        # Compute score
        successes = rollout_stats["successes"]
        total_successes = np.concatenate([total_successes, successes], axis=0)
        success_rate = 100 * np.mean(total_successes, axis=0)
        score = np.exp(np.mean(np.log(1 + success_rate))) - 1

        # Get eval stats
        eval_stats = {
            "success_rate": {k: v for k, v in zip(TASKS, success_rate)},
            "score": score,
        }

        # Print stats
        print(f"\nepoch {epoch}:")
        print(json.dumps(train_stats, indent=2))
        print(json.dumps(eval_stats, indent=2))

        # run dormant
        if args.use_dormant and args.dormant_epoch > 0 and epoch > 0 and epoch % args.dormant_epoch == 0:
            # get obs
            print("##########Start running dormant at epoch: {}".format(epoch))
            data_loader = storage.get_data_loader(algorithm.ppo_nbatch)
            data_loader = list(data_loader)
            # TODO: now always get the first batch
            obs = data_loader[0]["obs"]
            states = data_loader[0]["states"] # for memory
            if args.dormant_decay:
                dormant_tau = (args.dormant_tau_max - args.dormant_tau)/config["nepoch"]*epoch + args.dormant_tau
            algorithm, dormant_info = run_redo(obs, states, algorithm, dormant_tau, True, False)
            print("dormant info: ", dormant_info)
            dormant_info["tau"] = dormant_tau
        else:
            dormant_info = {}

        # Log stats
        if args.log_stats:
            # JSON
            episode_lengths = rollout_stats["episode_lengths"]
            episode_rewards = rollout_stats["episode_rewards"]
            achievements = rollout_stats["achievements"]

            for i in range(len(episode_lengths)):
                rollout_stat = {
                    "length": int(episode_lengths[i]),
                    "reward": round(float(episode_rewards[i]), 1),
                }
                for j, task in enumerate(TASKS):
                    rollout_stat[f"achievement_{task}"] = int(achievements[i, j])

                log_file.write(json.dumps(rollout_stat) + "\n")
                log_file.flush()
            train_stats.update(dormant_info)
            # W&B
            logger.log(train_stats, epoch)
            logger.log(eval_stats, epoch)

        # Save checkpoint
        if args.save_ckpt and epoch % config["save_freq"] == 0:
            ckpt_path = os.path.join(ckpt_dir, f"agent-e{epoch:03}.pt")
            th.save(model.state_dict(), ckpt_path)


if __name__ == "__main__":
    # Parse arguments
    parser = argparse.ArgumentParser()
    parser.add_argument("--exp_name", type=str, required=True)
    parser.add_argument("--timestamp", type=str, default="debug")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--log_stats", action="store_true")
    parser.add_argument("--save_ckpt", action="store_true")
    parser.add_argument('--use_dormant', action='store_true', default=False)
    parser.add_argument("--dormant_epoch", type=int, default=1)
    parser.add_argument("--dormant_tau", type=float, default=0.05)
    parser.add_argument("--dormant_tau_max", type=float, default=0.25)
    parser.add_argument('--dormant_decay', action='store_true', default=False)
    parser.add_argument('--priority_replay', action='store_true', default=False)


    args = parser.parse_args()
    print(args)
    # Run main
    main(args)
