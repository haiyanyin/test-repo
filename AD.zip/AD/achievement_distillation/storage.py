from typing import Dict, Iterator

import torch as th
import torch.nn.functional as F
from torch.utils.data.sampler import BatchSampler, SubsetRandomSampler

from gym import spaces

from achievement_distillation.model.base import BaseModel
import numpy as np

class RolloutStorage:
    def __init__(
        self,
        nstep: int,
        nproc: int,
        observation_space: spaces.Box,
        action_space: spaces.Discrete,
        hidsize: int,
        device: th.device,
        priority_replay: int = False,
    ):
        # Params
        self.nstep = nstep
        self.nproc = nproc
        self.device = device

        # Get obs shape and action dim
        assert isinstance(observation_space, spaces.Box)
        assert isinstance(action_space, spaces.Discrete)
        obs_shape = getattr(observation_space, "shape")
        action_shape = (1,)

        # Tensors
        self.obs = th.zeros(nstep + 1, nproc, *obs_shape, device=device)
        self.actions = th.zeros(nstep, nproc, *action_shape, device=device).long()
        self.rewards = th.zeros(nstep, nproc, 1, device=device)
        self.masks = th.ones(nstep + 1, nproc, 1, device=device)
        self.vpreds = th.zeros(nstep + 1, nproc, 1, device=device)
        self.log_probs = th.zeros(nstep, nproc, 1, device=device)
        self.returns = th.zeros(nstep, nproc, 1, device=device)
        self.advs = th.zeros(nstep, nproc, 1, device=device)
        self.successes = th.zeros(nstep + 1, nproc, 22, device=device).long()
        self.timesteps = th.zeros(nstep + 1, nproc, 1, device=device).long()
        self.states = th.zeros(nstep + 1, nproc, hidsize, device=device)

        # Step
        self.step = 0

        # priori parameters
        self.priority_replay = priority_replay
        self.global_steps = 0
        self.priority_replay_steps = min(50, nstep)
        # self.priority_achivements = [
        #     [1,3,5,11,12,13,14,],
        #     [1,3,11,12,14],
        #     [1,3,11,12,21],
        #     [1,3,10,11,12,21],
        #     [1,3,10,11,12,21],
        # ]
        self.priority_achivements = [
            [6, 15,16],
            [6, 15,16, 5, 3, 11, 12, 14, 13,],
            [15,16, 5, 3, 11, 12, 14, 13,],
            [15,16, 5, 3, 11, 12, 14, 13,],
            [15,16, 5, 3, 11, 12, 14, 13,],
            [15,16, 5, 3, 11, 12, 14, 13,],
            [15,16, 5, 3, 11, 12, 14, 13,],
            [15,16, 5, 3, 11, 12, 14, 13,],
            [15,16, 5, 3, 11, 12, 14, 13,],
            [15,16, 5, 3, 11, 12, 14, 13,],
        ]

        self.switch_priority_achivement_steps = int(3e6//len(self.priority_achivements))
        self.achie_successes_count = th.zeros(22, device=device).long()
        print("self.switch_priority_achivement_steps", self.switch_priority_achivement_steps)

    def __getitem__(self, key: str) -> th.Tensor:
        return getattr(self, key)

    def get_inputs(self, step: int):
        inputs = {"obs": self.obs[step], "states": self.states[step]}
        return inputs

    def insert(
        self,
        obs: th.Tensor,
        latents: th.Tensor,
        actions: th.Tensor,
        rewards: th.Tensor,
        masks: th.Tensor,
        vpreds: th.Tensor,
        log_probs: th.Tensor,
        successes: th.Tensor,
        model: BaseModel,
        **kwargs,
    ):
        # Get prev successes, timesteps, and states
        prev_successes = self.successes[self.step]
        prev_states = self.states[self.step]
        prev_timesteps = self.timesteps[self.step]

        # Update timesteps
        timesteps = prev_timesteps + 1

        # Update states if new achievment is unlocked
        success_conds = successes != prev_successes
        success_conds = success_conds.any(dim=-1, keepdim=True)
        if success_conds.any():
            with th.no_grad():
                next_latents = model.encode(obs)
            states = next_latents - latents
            states = F.normalize(states, dim=-1)
            states = th.where(success_conds, states, prev_states)
        else:
            states = prev_states

        # Update successes, timesteps, and states if done
        done_conds = masks == 0
        successes = th.where(done_conds, 0, successes)
        timesteps = th.where(done_conds, 0, timesteps)
        states = th.where(done_conds, 0, states)

        # Update tensors
        self.obs[self.step + 1].copy_(obs)
        self.actions[self.step].copy_(actions)
        self.rewards[self.step].copy_(rewards)
        self.masks[self.step + 1].copy_(masks)
        self.vpreds[self.step].copy_(vpreds)
        self.log_probs[self.step].copy_(log_probs)
        self.successes[self.step + 1].copy_(successes)
        self.timesteps[self.step + 1].copy_(timesteps)
        self.states[self.step + 1].copy_(states)

        # Update step
        self.step = (self.step + 1) % self.nstep

    def reset(self):
        # Reset tensors
        self.obs[0].copy_(self.obs[-1])
        self.masks[0].copy_(self.masks[-1])
        self.successes[0].copy_(self.successes[-1])
        self.timesteps[0].copy_(self.timesteps[-1])
        self.states[0].copy_(self.states[-1])

        # Reset step
        self.step = 0
        # self.achie_successes_count.fill_(0)

    def compute_returns(self, gamma: float, gae_lambda: float):
        # Compute returns
        gae = 0
        for step in reversed(range(self.rewards.shape[0])):
            delta = (
                self.rewards[step]
                + gamma * self.vpreds[step + 1] * self.masks[step + 1]
                - self.vpreds[step]
            )
            gae = delta + gamma * gae_lambda * self.masks[step + 1] * gae
            self.returns[step] = gae + self.vpreds[step]
            self.advs[step] = gae

        # Compute advantages
        self.advs = (self.advs - self.advs.mean()) / (self.advs.std() + 1e-8)

    def get_data_loader(self, nbatch: int, verbos: bool = False) -> Iterator[Dict[str, th.Tensor]]:
        # Get sampler
        ndata = self.nstep * self.nproc
        assert ndata >= nbatch
        batch_size = ndata // nbatch
        self.global_steps += ndata

        if self.priority_replay:
            # select one achievement list
            phase_idx = min(len(self.priority_achivements)-1, int(self.global_steps // self.switch_priority_achivement_steps))
            # print(phase_idx, self.global_steps, self.switch_priority_achivement_steps)
            priority_achievements = self.priority_achivements[phase_idx]
            
            # count each achievements
            for achi_idx in range(self.achie_successes_count.shape[0]):
                new_success = self.successes[..., achi_idx].sum()
                self.achie_successes_count[achi_idx] += new_success
            
            # retrieve priority index
            sampler_index = []
            for achievement in priority_achievements:
                tmp_sampler_index = []
                
                idx_masks = self.successes[..., achievement] > 0
                active_idx = th.nonzero(idx_masks)
                num_success_achievements = len(active_idx)

                # check column by column
                idx_masks = th.sum(self.successes[..., achievement] > 0, 0)  # [nproc]
                active_idx = th.nonzero(idx_masks)[..., 0]
                # active_idx = [np.random.randint(self.nproc) for _ in range(5)]

                for col_id in active_idx:
                    last_row = th.argmax(self.successes[:, col_id, achievement])
                    assert last_row >= 0

                    # last_row  = np.random.randint(self.nstep)
                    start_row = max(0, last_row - self.priority_replay_steps)
                    # select sub-sequence from the column
                    sub_seq_row_idx = list(range(start_row, last_row+1))
                    if verbos:
                        print(f'rol_id:{start_row}:{last_row}, col_id: {col_id}', len(sub_seq_row_idx))
                    for item in sub_seq_row_idx:
                        flat_idx =  item * self.nproc + col_id
                        assert flat_idx < ndata 
                        tmp_sampler_index += [flat_idx]
                if verbos:
                    print(f'global_steps:{self.global_steps//3}, achievement_id:{achievement}', 
                            f'num_success:{num_success_achievements}', f'num_prio_data:{len(tmp_sampler_index)}')
                sampler_index += tmp_sampler_index

                # for idx in active_idx:
                #     col_idxes = list(range(self.nstep))
                #     col_idxes = [item * self.nproc + idx for item in col_idxes]
                #     sampler_index += col_idxes
            sampler_index.extend(range(ndata))
        else:
            sampler_index = range(ndata)

        # print('length of priority samples', len(list(sampler_index)))
        sampler = SubsetRandomSampler(sampler_index)
        sampler = BatchSampler(sampler, batch_size=batch_size, drop_last=True)

        # Sample batch
        obs = self.obs[:-1].view(-1, *self.obs.shape[2:])
        states = self.states[:-1].view(-1, *self.states.shape[2:])
        actions = self.actions.view(-1, *self.actions.shape[2:])
        vtargs = self.returns.view(-1, *self.returns.shape[2:])
        log_probs = self.log_probs.view(-1, *self.log_probs.shape[2:])
        advs = self.advs.view(-1, *self.advs.shape[2:])

        for indices in sampler:
            batch = {
                "obs": obs[indices],
                "states": states[indices],
                "actions": actions[indices],
                "vtargs": vtargs[indices],
                "log_probs": log_probs[indices],
                "advs": advs[indices],
            }
            yield batch
