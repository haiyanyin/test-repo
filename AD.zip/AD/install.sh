
python -m pip install pip==23.2 --upgrade
pip install opencv-python==3.4.17.63
